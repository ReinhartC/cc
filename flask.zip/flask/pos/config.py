class Config(object):
	SQLALCHEMY_DATABASE_URI = 'mysql://root:190797@localhost/pos'
	SQLALCHEMY_TRACK_MODIFICATIONS = False

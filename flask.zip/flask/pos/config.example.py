class Config(object):
	SQLALCHEMY_DATABASE_URI = 'mysql://username:password@localhost/database'
	SQLALCHEMY_TRACK_MODIFICATIONS = False
